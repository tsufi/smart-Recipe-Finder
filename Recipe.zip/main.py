# main.py
import os
import json
import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *

from components.scrollable_frame import ScrollableFrame
from ui.search import show_search
from ui.favorites import show_favorites
from ui.history import show_history
from ui.meal_planner import MealPlannerPanel
from data.storage import load_json
from constants.paths import HISTORY_FILE, FAVORITES_FILE
from ui.recipe_tab import RecipeTab
from utils.translator import Translator
from ui.settings import show_settings
from data.settings import load_settings

class RecipeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🍽️ Recipe Finder")
        self.root.geometry("1000x720")

        settings = load_settings()
        self.language = settings.get("language", "en")
        self.translator = Translator(self.language)

        self.history = load_json(HISTORY_FILE, [])
        self.favorites = load_json(FAVORITES_FILE, [])
        self.last_ingredients = ""
        self.last_diets = []
        self.meal_types = ["Any", "Breakfast", "Lunch", "Dinner", "Snack", "Brunch"]

        self.setup_layout()
        self.show_search()


    def setup_layout(self):
        self.sidebar = ttk.Frame(self.root, width=160)
        self.sidebar.pack(side="left", fill="y")

        self.main = ttk.Frame(self.root)
        self.main.pack(side="right", fill="both", expand=True)

        self.notebook = ttk.Notebook(self.main)
        self.notebook.pack(fill="both", expand=True)

        _ = self.translator._

        ttk.Button(self.sidebar, text=_("\ud83d\udd0d Search"), command=self.show_search).pack(fill="x", pady=5)
        ttk.Button(self.sidebar, text=_("\u2b50 Favorites"), command=self.show_favorites).pack(fill="x", pady=5)
        ttk.Button(self.sidebar, text=_("\ud83d\udcdc History"), command=self.show_history).pack(fill="x", pady=5)
        ttk.Button(self.sidebar, text=_("\ud83d\uddd3\ufe0f Meal Planner"), command=self.show_meal_planner).pack(fill="x", pady=5)
        ttk.Button(self.sidebar, text=_("\u2699 Settings"), command=lambda: show_settings(self)).pack(pady=5)

    def clear_main(self):
        for widget in self.main.winfo_children():
            widget.destroy()
        self.notebook = ttk.Notebook(self.main)
        self.notebook.pack(fill="both", expand=True)

    def display_recipe_tab(self, tab_control, basic_info, full_info):
        tab = RecipeTab(tab_control, basic_info, full_info)
        tab_control.select(tab.tab)

    def show_search(self):
        self.clear_main()
        show_search(self)

    def show_favorites(self):
        self.clear_main()
        show_favorites(self)

    def show_history(self):
        self.clear_main()
        show_history(self)

    def show_meal_planner(self):
        self.clear_main()
        MealPlannerPanel(self.notebook, self)

    def open_recipe(self, full_info, show_close=False):
        if not self.notebook or not self.notebook.winfo_exists():
            self.notebook = ttk.Notebook(self.main)
            self.notebook.pack(fill="both", expand=True)
        tab = RecipeTab(self.notebook, full_info, full_info, show_close=show_close)
        self.notebook.select(tab.tab)
        
    def tr(self, key):
        return self.translator._(key)

    def save_config(self):
        os.makedirs("data", exist_ok=True)
        with open("data/settings.json", "w", encoding="utf-8") as f:
            json.dump({"language": self.language}, f)

    def reload_language(self):
        from utils.translator import Translator
        from ui.settings import show_settings
        self.translator = Translator(self.language)
        self.clear_main()
        self.setup_layout()
        show_settings(self)

if __name__ == "__main__":
    root = ttk.Window(themename="darkly")
    app = RecipeApp(root)
    root.mainloop()
