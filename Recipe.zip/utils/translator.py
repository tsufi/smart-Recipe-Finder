# utils/translator.py
import json
import os
from pathlib import Path

class Translator:
    def __init__(self, lang="en"):
        self.language = lang
        self.translations = {}
        self.load_language(lang)

    def load_language(self, lang_code):
        lang_path = Path("lang") / f"{lang_code}.json"
        if lang_path.exists():
            with open(lang_path, encoding="utf-8") as f:
                self.translations = json.load(f)
            self.language = lang_code
        else:
            self.translations = {}
            self.language = "en"

    def _(self, key):
        return self.translations.get(key, key)
