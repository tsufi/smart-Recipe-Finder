HISTORY_FILE = "history.json"
FAVORITES_FILE = "favorites.json"
